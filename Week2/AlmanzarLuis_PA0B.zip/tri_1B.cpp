// Header files
#include <iostream>	// for console I/O
#include <cstdlib>

using namespace std;

// Global Constants
const char ASTERISK = '*';
const char SPACE = ' ';

// Global Function Prototypes
void printAsterisk();
void printSpace();
void printEndLine();

// main function/program
int main()
   {
     // program initialization

       // variable initialization

// output line 1
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 2
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 3
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printSpace();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 4
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printSpace();
	printSpace();
	printSpace();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 5
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 6
	printAsterisk();
	printAsterisk();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printSpace();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 7
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

// output line 8
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
	printAsterisk();
		printEndLine();

    // End program

       // make some vertical spaces
          // function: printEndLine
       printEndLine();
       printEndLine(); 

       // hold program
          // function: system/pause
       system( "pause" );

       // return success
       return 0;

   }  //  end of main function

// Supporting Function Implementations

void printAsterisk()
   {
    cout << '*';
   }

void printSpace()
   {
    cout << ' ';
   }

void printEndLine()
   {
    cout << endl;
   }


